﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace HPSocketCS
{
    public class HttpsServer : SSLHttpServer
    {

    }
    public class SSLHttpServer : HttpServer
    {
        static int ObjectReferer = 0;
        static string SSLInitLock = "SSL初始化锁";

        /// <summary>
        /// 验证模式
        /// </summary>
        public SSLVerifyMode VerifyMode { get; set; }
        /// <summary>
        /// 证书文件（客户端可选）
        /// </summary>
        public string PemCertFile { get; set; }
        /// <summary>
        /// 私钥文件（客户端可选）
        /// </summary>
        public string PemKeyFile { get; set; }
        /// <summary>
        /// 私钥密码（没有密码则为空）
        /// </summary>
        public string KeyPasswod { get; set; }
        /// <summary>
        /// CA 证书文件或目录（单向验证或客户端可选）
        /// </summary>
        public string CAPemCertFileOrPath { get; set; }

        /// <summary>
        /// 名称：SNI 服务名称回调函数
        /// 描述：根据服务器名称选择 SSL 证书
        /// 返回值：
        /// 0	 -- 成功，使用默认 SSL 证书
        /// 正数	 -- 成功，使用返回值对应的 SNI 主机证书
        /// 负数	 -- 失败，中断 SSL 握手
        /// </summary>
        /// <param name="serverName"></param>
        /// <returns></returns>
        public SSLSdk.SNIServerNameCallback SNIServerNameCallback { get; set; }


        public SSLHttpServer()
        {
            Interlocked.Increment(ref ObjectReferer);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="_verifyModel">验证模式</param>
        /// <param name="_pemCertFile">证书文件</param>
        /// <param name="_pemKeyFile">私钥文件</param>
        /// <param name="_keyPasswod">私钥密码（没有密码则为空）</param>
        /// <param name="_caPemCertFileOrPath">CA 证书文件或目录（单向验证或客户端可选）</param>
        public SSLHttpServer(SSLVerifyMode _verifyModel, string _pemCertFile, string _pemKeyFile, string _keyPasswod, string _caPemCertFileOrPath, SSLSdk.SNIServerNameCallback _sniServerNameCallba)
        {
            Interlocked.Increment(ref ObjectReferer);
            this.VerifyMode = _verifyModel;
            this.PemCertFile = _pemCertFile;
            this.PemKeyFile = _pemKeyFile;
            this.KeyPasswod = _keyPasswod;
            this.CAPemCertFileOrPath = _caPemCertFileOrPath;
            this.SNIServerNameCallback = _sniServerNameCallba;
            Initialize();
        }

        ~SSLHttpServer()
        {
            Uninitialize();
        }

        protected override bool CreateListener()
        {
            if (IsCreate == true || pListener != IntPtr.Zero || pServer != IntPtr.Zero)
            {
                return false;
            }

            pListener = HttpSdk.Create_HP_HttpServerListener();
            if (pListener == IntPtr.Zero)
            {
                return false;
            }
            pServer = SSLHttpSdk.Create_HP_HttpsServer(pListener);
            if (pServer == IntPtr.Zero)
            {
                return false;
            }

            IsCreate = true;

            return true;
        }

        /// <summary>
        /// 初始化SSL环境
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public virtual bool Initialize()
        {
            lock (SSLInitLock)
            {
                if (SSLSdk.HP_SSL_IsValid() == false)
                {
                    PemCertFile = string.IsNullOrWhiteSpace(PemCertFile) ? null : PemCertFile;
                    PemKeyFile = string.IsNullOrWhiteSpace(PemKeyFile) ? null : PemKeyFile;
                    KeyPasswod = string.IsNullOrWhiteSpace(KeyPasswod) ? null : KeyPasswod;
                    CAPemCertFileOrPath = string.IsNullOrWhiteSpace(CAPemCertFileOrPath) ? null : CAPemCertFileOrPath;
                    
                    return SSLSdk.HP_SSL_Initialize(SSLSessionMode.Server, VerifyMode, PemCertFile, PemKeyFile, KeyPasswod, CAPemCertFileOrPath, SNIServerNameCallback);
                }

                return true;
            }
        }

        /// <summary>
        /// 反初始化SSL环境
        /// </summary>
        public virtual void Uninitialize()
        {
            if (Interlocked.Decrement(ref ObjectReferer) == 0)
            {
                SSLSdk.HP_SSL_Cleanup();
            }
        }

        public new bool Start()
        {
            if (SSLSdk.HP_SSL_IsValid() == false && Initialize() == false)
            {
                throw new Exception("法初始化SSL环境失败!");
            }
            return base.Start();
        }

        public override void Destroy()
        {
            Stop();

            if (pServer != IntPtr.Zero)
            {
                SSLHttpSdk.Destroy_HP_HttpsServer(pServer);
                pServer = IntPtr.Zero;
            }
            if (pListener != IntPtr.Zero)
            {
                HttpSdk.Destroy_HP_HttpServerListener(pListener);
                pListener = IntPtr.Zero;
            }

            IsCreate = false;
        }

        /// <summary>
        /// 名称：增加 SNI 主机证书（只用于服务端）
        /// 描述：SSL 服务端在 Initialize() 成功后可以调用本方法增加多个 SNI 主机证书
        /// 成功：正数, 返回 SNI 主机证书对应的索引，该索引用于在 SNI 回调函数中定位 SNI 主机
        /// 失败：负数, 可通过 SYS_GetLastError() 获取失败原因
        /// </summary>
        /// <param name="verifyMode">SSL 验证模式（参考 EnSSLVerifyMode）</param>
        /// <param name="pemCertFile">证书文件</param>
        /// <param name="pemKeyFile">私钥文件</param>
        /// <param name="keyPasswod">私钥密码（没有密码则为空）</param>
        /// <param name="caPemCertFileOrPath">CA 证书文件或目录（单向验证可选）</param>
        /// <returns></returns>
        public int AddServerContext(SSLVerifyMode verifyMode, string pemCertFile, string pemKeyFile, string keyPasswod, string caPemCertFileOrPath)
        {
            if (SSLSdk.HP_SSL_IsValid() == false)
            {
                throw new InvalidOperationException("请先调用Initialize()方法初始化SSL环境");
            }

            if (string.IsNullOrWhiteSpace(pemCertFile))
            {
                throw new ArgumentException("参数无效", pemCertFile);
            }
            if (string.IsNullOrWhiteSpace(pemKeyFile))
            {
                throw new ArgumentException("参数无效", pemKeyFile);
            }
            keyPasswod = string.IsNullOrWhiteSpace(keyPasswod) ? null : keyPasswod;
            caPemCertFileOrPath = string.IsNullOrWhiteSpace(caPemCertFileOrPath) ? null : caPemCertFileOrPath;

            return SSLSdk.HP_SSL_AddServerContext(verifyMode, pemCertFile, pemKeyFile, KeyPasswod, caPemCertFileOrPath);
        }
    }
}
