﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HPSocketCS
{
    public class EndPoint
    {
        public string Address { get; set; }
        public ushort Port { get; set; }
    }
}
